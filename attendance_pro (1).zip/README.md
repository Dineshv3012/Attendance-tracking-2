
# Attendance Pro (Flutter + Firebase)

Advanced attendance app with:
- Email/Google Auth
- Role-based access (user/admin via custom claims)
- Geofence (Haversine) + selfie capture on check-in/out
- Firestore + Storage
- Reports screen
- Cloud Function to compute daily hours
- Firestore & Storage Security Rules

## Quick Start

1) Install Flutter & Dart SDK, Android Studio or VS Code.
2) Create a Firebase project, add Android App (and iOS if needed).
3) Download `google-services.json` (Android) into `app/android/app/` and `GoogleService-Info.plist` (iOS) into `app/ios/Runner/`.
4) Enable Authentication providers: Email/Password and Google.
5) Create Firestore (in Native mode) and Storage.
6) Deploy security rules from `/firestore_rules` and Storage rules.
7) (Optional) Deploy Cloud Functions from `/cloud_functions` folder.
8) From `/app` run:
```
flutter pub get
flutter run
```

### Set Admin Role
To make an admin, set a custom claim:
```js
// In Cloud Functions shell or Admin SDK:
admin.auth().setCustomUserClaims(uid, { role: "admin" })
```

### Geofence
Edit allowed coordinates in `lib/services/attendance_service.dart`:
```dart
const allowedLat = 12.9716; // your office/school lat
const allowedLng = 77.5946; // your office/school lng
const radiusMeters = 300.0;
```

### Notes
- This is a production-ready scaffold. You can extend with QR/NFC, shift scheduling, parental portal, payroll export, etc.
- For iOS, add Camera/Location permissions in `Info.plist`. For Android, ensure required permissions in `AndroidManifest.xml`.
